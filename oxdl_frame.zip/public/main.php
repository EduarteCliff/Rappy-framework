<?php
	require("../config.php");
	function l_sql(){
		require("../class/class.sql.php");
		$sql = new sql();
		if(isset($sqlusr)){
			$sql->usr = $sqlusr;
			$sql->pwd = $sqlpwd;
			$sql->location = $sqlloc;
			if(isset($dbname)){
				$sql->db = $dbname;
			}
		}
	}
	function l_url(){
		require("../class/class.url.php");
	}
	function l_check_mobile(){
		require("../class/class.checkmobile.php");
	}
	function l_recaptcha(){
		require("../class/class.recaptcha.php");
		$recaptcha = new recaptcha();
		if(isset($recaptcha_code)){
			$recaptcha->secret = $recaptcha_code;
		}
	}
?>