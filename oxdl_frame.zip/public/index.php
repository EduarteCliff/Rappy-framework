<?php
	if(!file_exists("../config.php")){
		header("location:/install");
	}
?>
<!doctype html>

<html lang="zh">
	<head>
		<meta charset="utf-8">
		<title>恭喜 框架安装成功</title>
	</head>
	<body>
		<center>
			<h2>你已经完成安装oxdl frame</h2>
			<p>你现在可以删除index.php与install目录并开始开发了</p>
			<a href="//oxdl.cn">&copy; 2018-2019 oxdl. All Rights Reserved.</a>
		</center>
	</body>
</html>