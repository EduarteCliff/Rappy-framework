<!--
	recaptcha China
	ver 1.0
	date 2019/1/26
-->
<?php
/*
	方法
	v_recaptcha();
*/
	class recaptcha{
		public $url = "https://www.recaptcha.net";
		public $secret;
		
		function __construct(){
			if(!class_exists("url")){
				require("../class/class.url.php");
			}
		}
		
		function v_recaptcha(){
			if(isset($_POST["g-recaptcha-response"])){
				$url = new url();
				$value = $url->req("$this->url/recaptcha/api/siteverify","secret=$this->secret&response=" . $_POST["g-recaptcha-response"]);
				$value = json_decode($value,true);
				if($value["success"]){
					return true;
				}
			}
			return false;
		}
	}
?>